-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 22, 2016 at 06:53 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Leave_Application`
--

-- --------------------------------------------------------

--
-- Table structure for table `Admin`
--

CREATE TABLE `Admin` (
  `Google_UID` char(21) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Department`
--

CREATE TABLE `Department` (
  `Department_ID` varchar(5) NOT NULL,
  `Department_Name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Designation`
--

CREATE TABLE `Designation` (
  `Designation_ID` varchar(5) NOT NULL,
  `Title` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `LeaveHistory`
--

CREATE TABLE `LeaveHistory` (
  `AppliedBy` varchar(21) NOT NULL,
  `AppliedTo` varchar(21) NOT NULL,
  `FromDate` date NOT NULL,
  `ToDate` date NOT NULL,
  `LeaveType` varchar(20) NOT NULL,
  `Note` varchar(300) DEFAULT NULL,
  `Status` varchar(10) DEFAULT 'PENDING'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `LeavesAllotted`
--

CREATE TABLE `LeavesAllotted` (
  `Designation_ID` varchar(3) DEFAULT NULL,
  `SickLeave` int(11) DEFAULT NULL,
  `CasualLeave` int(11) DEFAULT NULL,
  `Vacation` int(11) DEFAULT NULL,
  `EarlyGo` int(11) DEFAULT NULL,
  `EarnedLeave` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `StaffDetails`
--

CREATE TABLE `StaffDetails` (
  `Google_UID` char(21) NOT NULL,
  `Email` varchar(320) NOT NULL,
  `FirstName` varchar(35) NOT NULL,
  `LastName` varchar(35) DEFAULT NULL,
  `Designation_ID` varchar(3) NOT NULL,
  `DateOfJoin` date DEFAULT NULL,
  `Contact` varchar(10) DEFAULT NULL,
  `Department_ID` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Admin`
--
ALTER TABLE `Admin`
  ADD KEY `Google_UID` (`Google_UID`);

--
-- Indexes for table `Department`
--
ALTER TABLE `Department`
  ADD PRIMARY KEY (`Department_ID`),
  ADD UNIQUE KEY `Department_Name` (`Department_Name`);

--
-- Indexes for table `Designation`
--
ALTER TABLE `Designation`
  ADD PRIMARY KEY (`Designation_ID`);

--
-- Indexes for table `LeaveHistory`
--
ALTER TABLE `LeaveHistory`
  ADD PRIMARY KEY (`AppliedBy`,`AppliedTo`,`FromDate`,`ToDate`,`LeaveType`),
  ADD KEY `AppliedTo` (`AppliedTo`);

--
-- Indexes for table `LeavesAllotted`
--
ALTER TABLE `LeavesAllotted`
  ADD KEY `Designation_ID` (`Designation_ID`);

--
-- Indexes for table `StaffDetails`
--
ALTER TABLE `StaffDetails`
  ADD PRIMARY KEY (`Google_UID`),
  ADD KEY `Department_ID` (`Department_ID`),
  ADD KEY `Designation_ID` (`Designation_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Admin`
--
ALTER TABLE `Admin`
  ADD CONSTRAINT `Admin_ibfk_1` FOREIGN KEY (`Google_UID`) REFERENCES `StaffDetails` (`Google_UID`);

--
-- Constraints for table `LeaveHistory`
--
ALTER TABLE `LeaveHistory`
  ADD CONSTRAINT `LeaveHistory_ibfk_1` FOREIGN KEY (`AppliedBy`) REFERENCES `StaffDetails` (`Google_UID`),
  ADD CONSTRAINT `LeaveHistory_ibfk_2` FOREIGN KEY (`AppliedTo`) REFERENCES `StaffDetails` (`Google_UID`);

--
-- Constraints for table `LeavesAllotted`
--
ALTER TABLE `LeavesAllotted`
  ADD CONSTRAINT `LeavesAllotted_ibfk_1` FOREIGN KEY (`Designation_ID`) REFERENCES `Designation` (`Designation_ID`);

--
-- Constraints for table `StaffDetails`
--
ALTER TABLE `StaffDetails`
  ADD CONSTRAINT `StaffDetails_ibfk_1` FOREIGN KEY (`Department_ID`) REFERENCES `Department` (`Department_ID`),
  ADD CONSTRAINT `StaffDetails_ibfk_2` FOREIGN KEY (`Designation_ID`) REFERENCES `Designation` (`Designation_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
